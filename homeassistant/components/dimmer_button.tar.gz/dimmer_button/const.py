"""Constants for the dimmer_button integration."""

DOMAIN = "dimmer_button"
